def text_to_ascii(text):
    return [ord(char) for char in text]

def extract_binary_message(ascii_codes):
    binary_message = ''
    space_count = 0  
    for code in ascii_codes:
        if code == 32:  
            space_count += 1
        else:
            if space_count == 1:
                binary_message += '0' 
            elif space_count == 2:
                binary_message += '1'  
            space_count = 0  
    return binary_message

def recover_message_from_file(input_file):
    with open(input_file, 'r') as file:
        text = file.read()
    
    ascii_codes = text_to_ascii(text)

    binary_message = extract_binary_message(ascii_codes)

    return binary_message

def save_binary_message_to_file(binary_message, output_file):
    with open(output_file, 'w') as file:
        file.write(binary_message)

recovered_binary_message = recover_message_from_file('hidden_text_complete.txt')

save_binary_message_to_file(recovered_binary_message, 'extract_binary.txt')

print("Da tach chuoi nhi phan va luu vao 'extract_binary.txt'.")

