def read_binary_message(input_file):
    with open(input_file, 'r') as file:
        return file.read().strip()  

def split_into_chunks(binary_message, k):
    if k < 3:
        raise ValueError("k >= 3.")
    
    return [binary_message[i:i+k] for i in range(0, len(binary_message), k)]

def process_chunks(chunks):
    result = []
    for chunk in chunks:
        if len(chunk) >= 2:  
            first_two_bits = chunk[:2]
            if first_two_bits == '01':
                result.append('0')
            elif first_two_bits == '10':
                result.append('1')
            else:
                result.append('null')  
        else:
            result.append('null')  
    
    return result

def save_result_to_file(result, output_file):
    with open(output_file, 'w') as file:
        for item in result:
            file.write(item + '\n')

def main():
    k = int(input("Nhap k: "))
    if k < 3:
        print("k >= 3")
        return

    binary_message = read_binary_message('extract_binary.txt')

    chunks = split_into_chunks(binary_message, k)

    result = process_chunks(chunks)

    save_result_to_file(result, 'processed_binary.txt')

    print("ket qua duoc luu vao file 'processed_binary.txt'.")

if __name__ == "__main__":
    main()

