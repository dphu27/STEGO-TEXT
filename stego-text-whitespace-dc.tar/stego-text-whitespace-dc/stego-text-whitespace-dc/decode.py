
binary_to_char_map = {
    '000000': '0', '000001': '1', '000010': '2', '000011': '3', '000100': '4',
    '000101': '5', '000110': '6', '000111': '7', '001000': '8', '001001': '9',
    '010001': 'A', '010010': 'B', '010011': 'C', '010100': 'D', '010101': 'E',
    '101100': 'F', '010110': 'G', '010111': 'H', '011000': 'I', '100000': 'J',
    '100001': 'K', '100010': 'L', '100011': 'M', '100100': 'N', '100101': 'O',
    '100110': 'P', '100111': 'Q', '101000': 'R', '110001': 'S', '110010': 'T',
    '110011': 'U', '110100': 'V', '110101': 'W', '010000': ' ',  

}

def binary_to_text(binary_message):
    text = ''
    for i in range(0, len(binary_message), 6):
        byte = binary_message[i:i+6]
        if len(byte) == 6:  
            text += binary_to_char_map.get(byte, '')  
    return text

def main():
    with open('processed_binary.txt', 'r') as file:
        binary_message = file.read().strip().replace('\n', '')  

    hidden_text = binary_to_text(binary_message)

    print("Thong diep da giau:", hidden_text)

if __name__ == "__main__":
    main()

