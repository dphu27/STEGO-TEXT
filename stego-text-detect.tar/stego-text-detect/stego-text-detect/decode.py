import sys

# Function to convert text to ASCII codes
def text_to_ascii(text):
    return [ord(char) for char in text]

# Function to extract binary message based on spaces
def extract_binary_message(ascii_codes):
    binary_message = ''
    space_count = 0  
    for code in ascii_codes:
        if code == 32:  
            space_count += 1
        else:
            if space_count == 1:
                binary_message += '0' 
            elif space_count == 2:
                binary_message += '1'  
            space_count = 0  
    return binary_message

# Function to convert binary message back to text
def binary_to_text(binary_message):
    binary_to_char_map = {
        '000000': '0', '000001': '1', '000010': '2', '000011': '3', '000100': '4',
        '000101': '5', '000110': '6', '000111': '7', '001000': '8', '001001': '9',
        '010001': 'A', '010010': 'B', '010011': 'C', '010100': 'D', '010101': 'E',
        '101100': 'F', '010110': 'G', '010111': 'H', '011000': 'I', '100000': 'J',
        '100001': 'K', '100010': 'L', '100011': 'M', '100100': 'N', '100101': 'O',
        '100110': 'P', '100111': 'Q', '101000': 'R', '110001': 'S', '110010': 'T',
        '110011': 'U', '110100': 'V', '110101': 'W', '010000': ' ',  
    }

    text = ''
    for i in range(0, len(binary_message), 6):
        byte = binary_message[i:i+6]
        if len(byte) == 6:  
            text += binary_to_char_map.get(byte, '')  
    return text

# Function to process binary from the file
def process_binary_from_file(input_file, k):
    # Step 1: Read data from file
    with open(input_file, 'r', encoding='utf-8') as file:
        text = file.read()

    # Step 2: Convert text to ASCII
    ascii_codes = text_to_ascii(text)

    # Step 3: Extract binary message based on spaces
    binary_message = extract_binary_message(ascii_codes)

    # Step 4: Split the binary message into chunks based on 'k' (user input)
    chunks = [binary_message[i:i+k] for i in range(0, len(binary_message), k)]
    
    # Step 5: Process the chunks to extract the binary message
    result = []
    for chunk in chunks:
        if len(chunk) >= 2:  
            first_two_bits = chunk[:2]
            if first_two_bits == '01':
                result.append('0')
            elif first_two_bits == '10':
                result.append('1')
            else:
                result.append('null')  
        else:
            result.append('null')  

    # Save the result to file
    with open('processed_binary.txt', 'w', encoding='utf-8') as file:
        for item in result:
            file.write(item + '\n')

    # Step 6: Convert the binary result back to text
    binary_message_from_chunks = ''.join(result).replace('null','')
    hidden_text = binary_to_text(binary_message_from_chunks)

    # Print the decoded message to the console
    print("Thông điệp đã giấu: ", hidden_text)

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 decode.py <input_file> [k]")
        print("Ví dụ: python3 decode.py hidden_text_complete.txt 6")
        return

    input_file = sys.argv[1]

    # Nếu có tham số k truyền vào, lấy, nếu không đặt mặc định k=6
    if len(sys.argv) >= 3:
        try:
            k = int(sys.argv[2])
        except ValueError:
            print("Giá trị k không hợp lệ, mặc định k=6")
            k = 6
    else:
        k = 6

    if k < 3:
        print("Lỗi: k phải lớn hơn hoặc bằng 3.")
        return

    process_binary_from_file(input_file, k)

if __name__ == "__main__":
    main()

