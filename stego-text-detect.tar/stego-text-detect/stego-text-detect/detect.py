import sys

def detect_binary_from_whitespace(text):
    bits = []
    i = 0
    n = len(text)

    while i < n:
        # Đọc 1 từ
        word_start = i
        while i < n and text[i] != ' ':
            i += 1
        word_end = i

        # Đếm số khoảng trắng liên tiếp sau từ
        space_count = 0
        while i < n and text[i] == ' ':
            space_count += 1
            i += 1

        # Nếu không phải từ cuối (còn khoảng trắng theo sau), decode bit
        if word_end > word_start and i < n:
            if space_count == 1:
                bits.append('0')
            elif space_count == 2:
                bits.append('1')
            else:
                # Bỏ qua các trường hợp khác
                pass

    return ''.join(bits)

def check_steganography_presence(binary_str):
    if '10' in binary_str or '01' in binary_str:
        return "Có thể văn bản đã được giấu tin bằng phương pháp sử dụng khoảng trắng."
    else:
        return "Văn bản không có thông điệp được giấu."

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 detect.py <filename>")
        sys.exit(1)

    filename = sys.argv[1]

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        print(f"File '{filename}' không tồn tại.")
        sys.exit(1)
    except Exception as e:
        print(f"Lỗi khi đọc file: {e}")
        sys.exit(1)

    binary_string = detect_binary_from_whitespace(content)
    print("Chuỗi nhị phân thu được:")
    print(binary_string)

    result = check_steganography_presence(binary_string)
    print("\nKết luận:")
    print(result)

if __name__ == "__main__":
    main()

