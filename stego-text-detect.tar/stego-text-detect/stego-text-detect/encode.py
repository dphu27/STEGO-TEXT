import os
import sys

# Function to convert message to binary (6-bit)
def text_to_binary_6bit(text):
    text_to_binary = {
        '0': '000000', '1': '000001', '2': '000010', '3': '000011', '4': '000100',
        '5': '000101', '6': '000110', '7': '000111', '8': '001000', '9': '001001',
        'A': '010001', 'B': '010010', 'C': '010011', 'D': '010100', 'E': '010101',
        'F': '101100', 'G': '010110', 'H': '010111', 'I': '011000', 'J': '100000',
        'K': '100001', 'L': '100010', 'M': '100011', 'N': '100100', 'O': '100101',
        'P': '100110', 'Q': '100111', 'R': '101000', 'S': '110001', 'T': '110010',
        'U': '110011', 'V': '110100', 'W': '110101', ' ': '010000',
    }
    text = text.upper()
    return ''.join(text_to_binary.get(char, 'UNKNOWN') for char in text)

def text_to_ascii(text):
    return [ord(char) for char in text]

def split_ascii_with_spaces(ascii_codes, k):
    ascii_chunks = []
    count = 0  
    chunk = []
    group_counter = 1  

    for code in ascii_codes:
        if code == 32:
            count += 1
        chunk.append(code)
        if count == k:
            ascii_chunks.append(f"A{group_counter}: " + ' '.join(map(str, chunk)))
            chunk = []  
            count = 0  
            group_counter += 1  
    if chunk:
        ascii_chunks.append(f"A{group_counter}: " + ' '.join(map(str, chunk)))
    return ascii_chunks

def hide_message_in_text(binary_message, ascii_chunks):
    count = 0  
    hidden_chunks = [] 
    for data in ascii_chunks:
        data = data.strip()
        chunk_list = data.split()
        if count < len(binary_message): 
            if binary_message[count] == '1':
                for i in range(len(chunk_list)):
                    if chunk_list[i] == '32':
                        chunk_list.insert(i + 1, '32')
                        break
            elif binary_message[count] == '0':
                count_32 = 0
                for i in range(len(chunk_list)):
                    if chunk_list[i] == '32':
                        count_32 += 1
                        if count_32 == 2:  
                            chunk_list.insert(i + 1, '32')
                            break
            count += 1  
        hidden_chunks.append(' '.join(chunk_list))
    with open('Steg.txt', 'w', encoding='utf-8') as file2:
        file2.write('\n'.join(hidden_chunks) + '\n')
    return "OK."

def convert_to_text_from_steg(steg_file):
    with open(steg_file, 'r', encoding='utf-8') as file:
        text = ''
        for line in file:
            line = line.split(':')[-1].strip()  
            ascii_codes = line.split()
            text += ''.join(chr(int(code)) for code in ascii_codes)
    return text

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 encode.py <input_cover_file>")
        return

    demo_file = sys.argv[1]

    msg = input("Nhập thông điệp cần giấu: ").strip()
    if not msg:
        print("Vui lòng nhập thông điệp cần giấu.")
        return

    try:
        k = int(input("Nhập số khoảng trắng (k >= 3): ").strip())
    except ValueError:
        print("Giá trị k không hợp lệ.")
        return

    if k < 3:
        print("Số khoảng trắng k phải lớn hơn hoặc bằng 3.")
        return

    if not os.path.isfile(demo_file):
        print(f"File '{demo_file}' không tồn tại.")
        return

    try:
        binary_msg = text_to_binary_6bit(msg)
        if 'UNKNOWN' in binary_msg:
            print("Có ký tự không hỗ trợ trong thông điệp. Vui lòng chỉ nhập số 0-9, chữ A-W và dấu cách.")
            return

        with open('binary_message.txt', 'w', encoding='utf-8') as f:
            f.write(binary_msg)

        with open(demo_file, 'r', encoding='utf-8') as file:
            text = file.read()
        ascii_codes = text_to_ascii(text)
        ascii_chunks = split_ascii_with_spaces(ascii_codes, k)
        with open('ascii_message.txt', 'w', encoding='utf-8') as f:
            f.write('\n'.join(ascii_chunks))

        result_message = hide_message_in_text(binary_msg, ascii_chunks)
        hidden_text = convert_to_text_from_steg('Steg.txt')
        with open('stego.txt', 'w', encoding='utf-8') as output_file:
            output_file.write(hidden_text)

        print(result_message)
        print("Đã lưu thông điệp vào 'stego.txt'.")
    except Exception as e:
        print(f"Đã có lỗi xảy ra: {str(e)}")

if __name__ == "__main__":
    main()

