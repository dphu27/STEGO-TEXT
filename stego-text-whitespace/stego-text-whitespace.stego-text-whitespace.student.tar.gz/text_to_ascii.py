def text_to_ascii(text):
    return [ord(char) for char in text]

def split_ascii_with_spaces(ascii_codes, k):
    ascii_chunks = []
    count = 0  
    chunk = []

    for code in ascii_codes:
        if code == 32:
            count += 1
        
        chunk.append(code)


        if count == k:
            ascii_chunks.append(' '.join(map(str, chunk)))
            chunk = []  
            count = 0  

    if chunk:
        ascii_chunks.append(' '.join(map(str, chunk)))
    
    return ascii_chunks


file_path = 'demo.txt'  
try:
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()  

    N = text.count(' ')  

    k = int(input("Nhap so khoang trang (k>=3): "))
    
    num_chunks = N // k


    msg = "HIDDEN"  
    length_msg = len(msg)  

    if num_chunks >= length_msg:
        ascii_codes = text_to_ascii(text)

        ascii_chunks = split_ascii_with_spaces(ascii_codes, k)

        for chunk in ascii_chunks:
            print(chunk)
    else:
        print(f"Loi: so luong choi con khong du chua thong diep. Can {length_msg} chuoi con.")
        
except FileNotFoundError:
    print(f"File '{file_path}' khong tim thay.")

