
text_to_binary = {
    '0': '000000', '1': '000001', '2': '000010', '3': '000011', '4': '000100',
    '5': '000101', '6': '000110', '7': '000111', '8': '001000', '9': '001001',
    'A': '010001', 'B': '010010', 'C': '010011', 'D': '010100', 'E': '010101',
    'F': '101100', 'G': '010110', 'H': '010111', 'I': '011000', 'J': '100000',
    'K': '100001', 'L': '100010', 'M': '100011', 'N': '100100', 'O': '100101',
    'P': '100110', 'Q': '100111', 'R': '101000', 'S': '110001', 'T': '110010',
    'U': '110011', 'V': '110100', 'W': '110101', ' ': '010000',
}

def text_to_binary_6bit(text):
    return ' '.join(text_to_binary.get(char, 'UNKNOWN') for char in text)

input_text = input("Nhap thong diep can giau bang chu in hoa: ")
binary_output = text_to_binary_6bit(input_text)
print(binary_output)
