import sys
text = sys.argv[1]
for c in text:
    print(format(ord(c), '08b'), end=' ')

