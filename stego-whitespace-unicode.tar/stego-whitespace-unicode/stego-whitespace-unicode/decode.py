# Các ký tự Unicode khoảng trắng đặc biệt (EQUIV_DCHAR)
EQUIV_DCHAR = [
    '\u0020',  # SPACE
    '\u00A0',  # NO-BREAK SPACE
    '\u2000',  # EN QUAD
    '\u2001',  # EM QUAD
    '\u2002',  # EN SPACE
    '\u2003',  # EM SPACE
    '\u2004',  # THREE-PER-EM SPACE
    '\u2005',  # FOUR-PER-EM SPACE
    '\u2006',  # SIX-PER-EM SPACE
    '\u2007',  # FIGURE SPACE
    '\u2008',  # PUNCTUATION SPACE
    '\u2009',  # THIN SPACE
    '\u200A',  # HAIR SPACE
    '\u202F',  # NARROW NO-BREAK SPACE
    '\u205F',  # MEDIUM MATHEMATICAL SPACE
    '\u3000'   # IDEOGRAPHIC SPACE
]

# Hàm giải mã thông điệp
def decode(concealed):
    bitstream = ''
    
    # Duyệt qua từng ký tự trong văn bản giấu tin
    for char in concealed:
        if char in EQUIV_DCHAR:
            # Lấy index của ký tự trong EQUIV_DCHAR
            index = EQUIV_DCHAR.index(char)
            # Chuyển index thành nhóm 4 bit và nối vào bitstream
            bitstream += format(index, '04b')  # Chuyển index thành 4 bit
            
    # Chia bitstream thành các nhóm 8 bit và chuyển thành ký tự
    message = ''
    for i in range(0, len(bitstream), 8):
        byte_bits = bitstream[i:i+8]
        if len(byte_bits) < 8:
            break
        # Chuyển nhóm 8 bit thành ký tự
        char = chr(int(byte_bits, 2))
        message += char
    
    return message

# Đọc văn bản giấu tin từ file
with open('stego.txt', 'r', encoding='utf-8') as file:
    concealed_text = file.read()

# Giải mã thông điệp
extracted_message = decode(concealed_text)
print("Thông điệp đã giải mã:", extracted_message)

