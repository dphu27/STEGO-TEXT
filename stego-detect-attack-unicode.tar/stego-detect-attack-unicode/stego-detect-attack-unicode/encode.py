# Các ký tự Unicode khoảng trắng đặc biệt (EQUIV_DCHAR)
EQUIV_DCHAR = [
    '\u0020',  # SPACE
    '\u00A0',  # NO-BREAK SPACE
    '\u2000',  # EN QUAD
    '\u2001',  # EM QUAD
    '\u2002',  # EN SPACE
    '\u2003',  # EM SPACE
    '\u2004',  # THREE-PER-EM SPACE
    '\u2005',  # FOUR-PER-EM SPACE
    '\u2006',  # SIX-PER-EM SPACE
    '\u2007',  # FIGURE SPACE
    '\u2008',  # PUNCTUATION SPACE
    '\u2009',  # THIN SPACE
    '\u200A',  # HAIR SPACE
    '\u202F',  # NARROW NO-BREAK SPACE
    '\u205F',  # MEDIUM MATHEMATICAL SPACE
    '\u3000'   # IDEOGRAPHIC SPACE
]

# Hàm mã hóa (giấu bitstream vào văn bản)
def encode(bitstream, cover):
    concealed = ''
    bit_index = 0
    
    for char in cover:
        if char == ' ':  # Chỉ thay thế các dấu cách
            if bit_index + 4 <= len(bitstream):
                bits = bitstream[bit_index:bit_index + 4]  # Lấy 4 bit
                index = int(bits, 2)
                concealed += EQUIV_DCHAR[index]
                bit_index += 4
            else:
                concealed += EQUIV_DCHAR[0]  # Nếu không còn đủ 4 bit, dùng SPACE gốc
        else:
            concealed += char  # Giữ nguyên các ký tự khác
    return concealed

# Hàm chính
def main():
    # Đọc văn bản từ file cover.txt
    try:
        with open('cover.txt', 'r', encoding='utf-8') as file:
            cover_text = file.read()
    except FileNotFoundError:
        print("File 'cover.txt' không tồn tại. Hãy tạo file này trước.")
        return
    
    # Nhập bitstream từ người dùng
    bitstream = input("Nhập chuỗi bitstream (chuỗi gồm 0 và 1): ").replace(" ", "")
    
    # Kiểm tra hợp lệ (bội số của 4 và chỉ có 0 hoặc 1)
    if any(c not in '01' for c in bitstream):
        print("❌ Bitstream không hợp lệ! Chỉ được chứa 0 và 1.")
        return
    if len(bitstream) % 4 != 0:
        print("❌ Độ dài bitstream phải chia hết cho 4.")
        return

    # Mã hóa
    concealed_text = encode(bitstream, cover_text)

    # Lưu kết quả
    with open('stego.txt', 'w', encoding='utf-8') as file:
        file.write(concealed_text)

    print("✅ Đã giấu bitstream vào file 'stego.txt'.")

# Chạy
if __name__ == "__main__":
    main()

