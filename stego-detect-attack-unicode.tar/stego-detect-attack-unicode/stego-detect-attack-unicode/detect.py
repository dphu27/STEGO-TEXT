import unicodedata
import sys

# Danh sách Unicode khoảng trắng đặc biệt cần phát hiện
WHITESPACE_UNICODE_SET = {
    '\u0009', '\u000A', '\u000B', '\u000C', '\u000D',
    '\u0020', '\u0085', '\u00A0', '\u1680', '\u180E',
    '\u2000', '\u2001', '\u2002', '\u2003', '\u2004',
    '\u2005', '\u2006', '\u2007', '\u2008', '\u2009',
    '\u200A', '\u2028', '\u2029', '\u202F', '\u205F',
    '\u3000'
}

def detect_whitespace_unicode(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        print(f"❌ File '{file_path}' không tồn tại.")
        return

    print(f"📄 Kiểm tra ký tự khoảng trắng Unicode trong file: {file_path}\n")

    found = False
    for i, c in enumerate(content):
        if c in WHITESPACE_UNICODE_SET:
            name = unicodedata.name(c, "UNKNOWN")
            code = f"U+{ord(c):04X}"
            printable = repr(c)  # dạng '\u2002' hoặc '\t'
            print(f"Vị trí {i}: {printable} | {code} | {name}")
            found = True

    if not found:
        print("✅ Không tìm thấy ký tự khoảng trắng Unicode đặc biệt nào.")

# Sử dụng từ dòng lệnh
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Cách dùng: python3 detect_unicode_whitespace.py <tên_file>")
    else:
        detect_whitespace_unicode(sys.argv[1])

