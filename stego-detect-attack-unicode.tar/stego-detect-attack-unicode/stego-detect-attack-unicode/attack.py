import sys
import random
from collections import Counter

# Danh sách các ký tự Unicode khoảng trắng đặc biệt, sắp xếp theo mã Unicode tăng dần
WHITESPACE_UNICODE_LIST = sorted([
    '\u0020', '\u00A0', '\u2000', '\u2001', '\u2002', '\u2003', '\u2004',
    '\u2005', '\u2006', '\u2007', '\u2008', '\u2009', '\u200A', '\u202F',
    '\u205F', '\u3000'
], key=lambda c: ord(c))

def find_unique_whitespace_chars(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    chars_in_text = [c for c in content if c in WHITESPACE_UNICODE_LIST]
    # Sắp xếp unique_chars theo mã Unicode tăng dần
    unique_chars = sorted(list(set(chars_in_text)), key=lambda c: ord(c))
    for ch in WHITESPACE_UNICODE_LIST:
        if ch not in unique_chars:
            unique_chars.append(ch)
        if len(unique_chars) == 16:
            break
    return unique_chars, chars_in_text

def generate_random_mapping(unique_chars):
    mapping = unique_chars[:]
    random.shuffle(mapping)
    return mapping

def generate_sorted_mapping(unique_chars):
    # Trả về mapping theo thứ tự mã Unicode tăng dần
    return sorted(unique_chars, key=lambda c: ord(c))

def generate_fixed_mapping(unique_chars):
    # Đảm bảo các ký tự đặc biệt ở đúng vị trí
    mapping = [None] * 16
    mapping[0] = '\u0020'
    mapping[1] = '\u00A0'
    mapping[15] = '\u3000'
    # Lấy các ký tự còn lại, loại bỏ 3 ký tự trên, sắp xếp tăng dần
    remain = [c for c in unique_chars if c not in ('\u0020', '\u00A0', '\u3000')]
    remain_sorted = sorted(remain, key=lambda c: ord(c))
    # Điền vào các vị trí còn lại
    idx = 2
    for c in remain_sorted:
        if idx == 15:
            break
        mapping[idx] = c
        idx += 1
    return mapping

def encode_to_bitstream(chars_in_text, mapping):
    char_to_index = {ch: idx for idx, ch in enumerate(mapping)}
    bitstream = ''
    for i in range(0, len(chars_in_text), 2):
        if i+1 >= len(chars_in_text):
            break
        c1, c2 = chars_in_text[i], chars_in_text[i+1]
        if c1 not in char_to_index or c2 not in char_to_index:
            return None
        index1 = char_to_index[c1]
        index2 = char_to_index[c2]
        byte_val = (index1 << 4) | index2
        bits = format(byte_val, '08b')
        bitstream += bits
    return bitstream

def bitstream_to_ascii_filtered(bitstream):
    chars = []
    for i in range(0, len(bitstream), 8):
        byte = bitstream[i:i+8]
        if len(byte) < 8:
            break
        val = int(byte, 2)
        ch = chr(val)
        if ch.isalnum():  # chỉ giữ ký tự chữ hoặc số
            chars.append(ch)
        else:
            chars.append('?')  # thay bằng '?' nếu không hợp lệ
    return ''.join(chars)

def guess_mapping_by_frequency(chars_in_text, unique_chars):
    freq = Counter(chars_in_text)
    # Sắp xếp unique_chars theo tần suất giảm dần
    sorted_by_freq = sorted(unique_chars, key=lambda c: -freq[c])
    mapping = [None] * 16
    mapping[0] = sorted_by_freq[0]  # Ký tự xuất hiện nhiều nhất -> index 0
    remain = [c for c in sorted_by_freq if c != mapping[0]]
    idx = 1
    for c in remain:
        mapping[idx] = c
        idx += 1
    return mapping

def fitness(bitstream):
    # Đếm số ký tự ASCII hợp lệ (chữ, số, khoảng trắng)
    chars = []
    for i in range(0, len(bitstream), 8):
        byte = bitstream[i:i+8]
        if len(byte) < 8:
            break
        val = int(byte, 2)
        ch = chr(val)
        if ch.isalnum() or ch in ' \n':
            chars.append(ch)
    return len(chars)

def hill_climbing(chars_in_text, unique_chars, max_iter=1000, init_mapping=None):
    if init_mapping is not None:
        mapping = init_mapping[:]
    else:
        mapping = unique_chars[:]
        random.shuffle(mapping)
    best_mapping = mapping[:]
    bitstream = encode_to_bitstream(chars_in_text, mapping)
    best_score = fitness(bitstream) if bitstream else 0

    # Chỉ hoán đổi các vị trí từ 2 đến 14
    swap_indices = list(range(2, 15))
    for _ in range(max_iter):
        i, j = random.sample(swap_indices, 2)
        mapping[i], mapping[j] = mapping[j], mapping[i]
        bitstream = encode_to_bitstream(chars_in_text, mapping)
        if bitstream is None:
            mapping[i], mapping[j] = mapping[j], mapping[i]
            continue
        score = fitness(bitstream)
        if score > best_score:
            best_score = score
            best_mapping = mapping[:]
        else:
            mapping[i], mapping[j] = mapping[j], mapping[i]
    return best_mapping

def main():
    if len(sys.argv) != 3:
        print("Usage: python attack.py <file> <num_trials>")
        return

    file_path = sys.argv[1]
    num_trials = int(sys.argv[2])

    unique_chars, chars_in_text = find_unique_whitespace_chars(file_path)
    print(f"Found {len(unique_chars)} unique whitespace chars in text.")

    # Thử mapping mặc định: theo thứ tự mã Unicode tăng dần
    mapping = generate_sorted_mapping(unique_chars)
    bitstream = encode_to_bitstream(chars_in_text, mapping)
    if bitstream is not None:
        message = bitstream_to_ascii_filtered(bitstream)
        print(f"Sorted mapping: {[f'U+{ord(c):04X}' for c in mapping]}")
        print(f"Decoded message (sorted mapping, filtered a-zA-Z0-9): {message[:100]}")
        print("-" * 60)

    # Thử nhiều mapping ngẫu nhiên
    for trial in range(1, num_trials + 1):
        mapping = generate_random_mapping(unique_chars)
        bitstream = encode_to_bitstream(chars_in_text, mapping)
        if bitstream is None:
            print(f"Trial #{trial}: Mapping error, skipping.")
            continue

        message = bitstream_to_ascii_filtered(bitstream)

        print(f"Trial #{trial} - Mapping: {[f'U+{ord(c):04X}' for c in mapping]}")
        print(f"Decoded message (filtered a-zA-Z0-9): {message[:100]}")
        print("-" * 60)

    # Thử đoán mapping dựa trên tần suất xuất hiện
    mapping = guess_mapping_by_frequency(chars_in_text, unique_chars)
    bitstream = encode_to_bitstream(chars_in_text, mapping)
    if bitstream is not None:
        message = bitstream_to_ascii_filtered(bitstream)
        print(f"Guessed mapping by frequency: {[f'U+{ord(c):04X}' for c in mapping]}")
        print(f"Decoded message (guessed mapping, filtered a-zA-Z0-9): {message[:100]}")
        print("-" * 60)

    # Hill climbing từ mapping tần suất
    best_mapping = hill_climbing(chars_in_text, unique_chars, max_iter=num_trials, init_mapping=mapping)
    bitstream = encode_to_bitstream(chars_in_text, best_mapping)
    if bitstream is not None:
        message = bitstream_to_ascii_filtered(bitstream)
        print(f"Best mapping by hill climbing (from freq): {[f'U+{ord(c):04X}' for c in best_mapping]}")
        print(f"Decoded message (hill climbing, filtered a-zA-Z0-9): {message[:100]}")
        print("-" * 60)

if __name__ == "__main__":
    main()

